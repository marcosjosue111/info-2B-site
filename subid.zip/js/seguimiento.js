// Aquí se cargará el seguimiento desde JSON
console.log('Seguimiento iniciado');